# Fixed operation worker. Never invoke on the development host.
# Parameters arrive as bounded typed JSON on stdin; no caller text is evaluated.
$ErrorActionPreference='Stop'
$WarningPreference='SilentlyContinue'
$VerbosePreference='SilentlyContinue'
$DebugPreference='SilentlyContinue'
$ProgressPreference='SilentlyContinue'
$InformationPreference='SilentlyContinue'
$PSModuleAutoloadingPreference='None'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$reply=[ordered]@{SchemaVersion=1;OperationId=$null;State='Unknown';Error='EvidenceIncomplete';NativeReturned=$false;Local=$null;Active=$null;Profile=$null;Before=$null;After=$null}
function Exact-Properties($Object,[string[]]$Names) {
    if($null -eq $Object){throw 'Fields'}
    $actual=@($Object.PSObject.Properties.Name)
    if($actual.Count -ne $Names.Count){throw 'Fields'}
    foreach($name in $Names){if($name -cnotin $actual){throw 'Fields'}}
}
function Import-FixedModule([string]$Name) {
    if($Name -cnotin @('Microsoft.PowerShell.Utility','NetSecurity')){throw 'Module'}
    $path=[IO.Path]::Combine($PSHOME,'Modules',$Name,($Name+'.psd1'))
    Microsoft.PowerShell.Core\Import-Module -Name $path -ErrorAction Stop -WarningAction SilentlyContinue | Microsoft.PowerShell.Core\Out-Null
}
function One($Values) { $items=@($Values);if($items.Count -ne 1){throw 'FilterCardinality'};return $items[0] }
function Scalar($Value) { $values=@($Value);if($values.Count -ne 1 -or $null -eq $values[0]){throw 'MissingField'};return [string]$values[0] }
function Snapshot($Rule,[string]$Store) {
    $app=One (NetSecurity\Get-NetFirewallApplicationFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $address=One (NetSecurity\Get-NetFirewallAddressFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $port=One (NetSecurity\Get-NetFirewallPortFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $service=One (NetSecurity\Get-NetFirewallServiceFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $iface=One (NetSecurity\Get-NetFirewallInterfaceFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $type=One (NetSecurity\Get-NetFirewallInterfaceTypeFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    $security=One (NetSecurity\Get-NetFirewallSecurityFilter -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    return [ordered]@{
        Complete=$true;PolicyStoreSource=$(if($Store -ceq 'PersistentStore'){'PersistentStore'}else{Scalar $Rule.PolicyStoreSource});PolicyStoreSourceType=$(if($Store -ceq 'PersistentStore'){'Local'}else{Scalar $Rule.PolicyStoreSourceType})
        Fields=[ordered]@{
            Name=(Scalar $Rule.Name);Group=(Scalar $Rule.Group);Enabled=(Scalar $Rule.Enabled);Direction=(Scalar $Rule.Direction);Action=(Scalar $Rule.Action);Profile=(Scalar $Rule.Profile)
            Program=(Scalar $app.Program);Package=(Scalar $app.Package);Protocol=(Scalar $port.Protocol);LocalPort=(Scalar $port.LocalPort);RemotePort=(Scalar $port.RemotePort)
            LocalAddress=(Scalar $address.LocalAddress);RemoteAddress=(Scalar $address.RemoteAddress);Service=(Scalar $service.Service);InterfaceAlias=(Scalar $iface.InterfaceAlias);InterfaceType=(Scalar $type.InterfaceType)
            Authentication=(Scalar $security.Authentication);Encryption=(Scalar $security.Encryption);OverrideBlockRules=(Scalar $security.OverrideBlockRules)
            LocalUser=(Scalar $security.LocalUser);RemoteUser=(Scalar $security.RemoteUser);RemoteMachine=(Scalar $security.RemoteMachine);EdgeTraversalPolicy=(Scalar $Rule.EdgeTraversalPolicy)
        }
    }
}
function Find-Exact([string]$Name,[string]$Store) {
    # Name is generated from a canonical GUID. No wildcard-capable caller string reaches this parameter.
    # A suppressed provider error cannot be interpreted as rule absence.
    $rules=@(foreach($candidate in (NetSecurity\Get-NetFirewallRule -PolicyStore $Store -ErrorAction Stop)){if([string]$candidate.Name -ceq $Name){$candidate}})
    if($rules.Count -gt 1){throw 'AmbiguousRule'}
    if($rules.Count -eq 0){return $null}
    if([string]$rules[0].Name -cne $Name){throw 'NameMismatch'}
    return $rules[0]
}
function Assert-Expected($Snapshot,$Expected) {
    $names=@('Name','Group','Enabled','Direction','Action','Profile','Program','Protocol','LocalAddress','RemoteAddress','LocalPort','RemotePort','InterfaceType','InterfaceAlias','Service','Package','EdgeTraversalPolicy','Authentication','Encryption','OverrideBlockRules','LocalUser','RemoteUser','RemoteMachine')
    Exact-Properties $Expected $names
    if($null -eq $Snapshot -or -not $Snapshot.Complete){throw 'OwnershipDrift'}
    foreach($key in $names){$a=[string]$Snapshot.Fields[$key];$b=[string]$Expected.$key;if($key -ceq 'Program'){if(-not [String]::Equals($a,$b,[StringComparison]::OrdinalIgnoreCase)){throw 'OwnershipDrift'}}elseif($a -cne $b){throw 'OwnershipDrift'}}
}
try {
    # The helper validates dependency hashes/ACLs and the fixed system module closure while holding handles.
    # This script is never a general remote/CLI command interface.
    if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'Platform'}
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$principal=[Security.Principal.WindowsPrincipal]::new($identity);if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'ElevationRequired'}}finally{$identity.Dispose()}
    Import-FixedModule 'Microsoft.PowerShell.Utility'
    $inputText=[Console]::In.ReadToEnd()
    if([Text.Encoding]::UTF8.GetByteCount($inputText) -gt 16384){throw 'InputLimit'}
    $request=Microsoft.PowerShell.Utility\ConvertFrom-Json -InputObject $inputText -ErrorAction Stop
    Exact-Properties $request @('SchemaVersion','OperationId','Action','RuleName','Program','Profile','Expected')
    if($request.SchemaVersion -ne 1){throw 'Schema'}
    $operationId=[Guid]::ParseExact([string]$request.OperationId,'D');if($operationId -eq [Guid]::Empty){throw 'OperationId'}
    $reply.OperationId=$operationId.ToString('D')
    if([string]$request.Action -cnotin @('Read','Add','Remove','EnableProfile')){throw 'Action'}
    Import-FixedModule 'NetSecurity'
    if($request.Action -ceq 'EnableProfile') {
        if([string]$request.Profile -cnotin @('Domain','Private','Public') -or $null -ne $request.Program -or $null -ne $request.Expected -or $null -ne $request.RuleName){throw 'Profile'}
        $before=One (NetSecurity\Get-NetFirewallProfile -PolicyStore PersistentStore -Name ([string]$request.Profile) -ErrorAction Stop)
        $reply.Profile=[string]$request.Profile;$reply.Before=[ordered]@{Enabled=(Scalar $before.Enabled);DefaultInboundAction=(Scalar $before.DefaultInboundAction);DefaultOutboundAction=(Scalar $before.DefaultOutboundAction)}
        # A fixed protected private record saves the exact profile pre-state before the one service call.
        # Directory/ancestor ACL+identity is verified and held by the host; client supplies no output path.
        $journalRoot=[IO.Path]::Combine([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData),'Solar System Shield','Journal','Rules')
        $intentPath=[IO.Path]::Combine($journalRoot,($operationId.ToString('D')+'.ProfileBefore.json'))
        $intent=Microsoft.PowerShell.Utility\ConvertTo-Json -InputObject ([ordered]@{SchemaVersion=1;OperationId=$operationId.ToString('D');Profile=$reply.Profile;Before=$reply.Before}) -Depth 3 -Compress
        $security=[Security.AccessControl.FileSecurity]::new();$security.SetAccessRuleProtection($true,$false);$security.SetOwner([Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))
        foreach($sid in @('S-1-5-18','S-1-5-32-544')){$security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),[Security.AccessControl.FileSystemRights]::FullControl,[Security.AccessControl.AccessControlType]::Allow))}
        $intentBytes=[Text.Encoding]::UTF8.GetBytes($intent)
        if($intentBytes.Length -gt 16384){throw 'ProfileIntentLimit'}
        $stream=[IO.FileStream]::new($intentPath,[IO.FileMode]::CreateNew,[Security.AccessControl.FileSystemRights]::Write,[IO.FileShare]::Read,4096,[IO.FileOptions]::WriteThrough,$security)
        try{$stream.Write($intentBytes,0,$intentBytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
        NetSecurity\Set-NetFirewallProfile -PolicyStore PersistentStore -Name ([string]$request.Profile) -Enabled True -ErrorAction Stop
        $reply.NativeReturned=$true
        $after=One (NetSecurity\Get-NetFirewallProfile -PolicyStore PersistentStore -Name ([string]$request.Profile) -ErrorAction Stop)
        $active=One (NetSecurity\Get-NetFirewallProfile -PolicyStore ActiveStore -Name ([string]$request.Profile) -ErrorAction Stop)
        $reply.After=[ordered]@{Enabled=(Scalar $after.Enabled);DefaultInboundAction=(Scalar $after.DefaultInboundAction);DefaultOutboundAction=(Scalar $after.DefaultOutboundAction)};$reply.Active=[ordered]@{Enabled=[string]$active.Enabled;AllowLocalFirewallRules=[string]$active.AllowLocalFirewallRules}
        $reply.State='Returned';$reply.Error='None'
    } else {
        if($null -ne $request.Profile){throw 'Profile'}
        $name=[string]$request.RuleName
        if(-not $name.StartsWith('SolarSystemShield-Block-',[StringComparison]::Ordinal)){throw 'RuleName'}
        $suffix=$name.Substring(24);$job=[Guid]::ParseExact($suffix,'D');if($job -eq [Guid]::Empty -or $name -cne ('SolarSystemShield-Block-'+$job.ToString('D'))){throw 'RuleName'}
        $local=Find-Exact $name 'PersistentStore'
        if($request.Action -ceq 'Add') {
            if($null -ne $local -or $null -eq $request.Expected){throw 'ExistingOrMissingSpec'}
            $program=[string]$request.Program
            if($program.Length -gt 240 -or $program -notmatch '^[A-Za-z]:\\' -or -not $program.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase)){throw 'Program'}
            if([string]$request.Expected.Name -cne $name -or [string]$request.Expected.Program -cne $program -or [string]$request.Expected.Group -cne 'SolarSystemShield.Managed'){throw 'Expected'}
            NetSecurity\New-NetFirewallRule -PolicyStore PersistentStore -Name $name -DisplayName $name -Group 'SolarSystemShield.Managed' -Enabled True -Direction Outbound -Action Block -Profile Any -Program $program -Protocol Any -LocalAddress Any -RemoteAddress Any -LocalPort Any -RemotePort Any -InterfaceType Any -InterfaceAlias Any -Service Any -Package Any -EdgeTraversalPolicy Block -Authentication NotRequired -Encryption NotRequired -OverrideBlockRules $false -ErrorAction Stop | Microsoft.PowerShell.Core\Out-Null
            $reply.NativeReturned=$true
        } elseif($request.Action -ceq 'Remove') {
            if($null -eq $local -or $null -eq $request.Expected -or $null -ne $request.Program){throw 'OwnershipUnknown'}
            Assert-Expected (Snapshot $local 'PersistentStore') $request.Expected
            NetSecurity\Remove-NetFirewallRule -InputObject $local -ErrorAction Stop
            $reply.NativeReturned=$true
        } elseif($null -ne $request.Program -or $null -ne $request.Expected){throw 'ReadParameters'}
        $after=Find-Exact $name 'PersistentStore';$effective=Find-Exact $name 'ActiveStore'
        if($null -ne $after){$reply.Local=Snapshot $after 'PersistentStore'}
        if($null -ne $effective){$reply.Active=Snapshot $effective 'ActiveStore'}
        $reply.State='Returned';$reply.Error='None'
    }
} catch {
    # Submitted calls whose reply/readback failed remain uncertain; never infer no change from a nonzero exit.
    $reply.State='Unknown';$reply.Error='NativeOrEvidenceFailure'
}
Microsoft.PowerShell.Utility\ConvertTo-Json -InputObject $reply -Depth 5 -Compress
if($reply.Error -cne 'None'){exit 2}
exit 0
