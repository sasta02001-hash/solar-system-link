﻿SSS 0.5.0.0 Windows x64 更新候選

本包改善背景健康狀態與部分資料說明。查詢失敗或資料過期仍顯示未知；這不是新的防毒引擎或已通過完整原生防護驗收。
防火牆、掃描及清理的受保護原生操作仍停用；不新增 native grant，也不作為 SSL 連線的額外條件。

請使用配套且已核對的安裝入口或既有 SSS 正常背景更新流程；不要手動覆蓋既有根、刪除更新資料、重新綁定或重建 genesis。
同根更新須由原簽署 catalog、Bootstrap、latest／期限／highwater 與舊程序正常退出機制完成。公開下載或簽章成功不代表已取得 activation／latest 資格。
SSS 背景啟動及更新沿用既有機制；SSL 仍須連網、最新版並通過本機／對端既有 SSS 檢查。更新後重連與第一張新畫面須另行確認，不恢復舊輸入 grant。

適用來源目標：Windows x64，需 .NET Framework 4.8。Windows 7 SP1 x64 僅有來源資格，POS 的實際 OS／架構與功能相容尚未驗收；不宣稱全平台相容。
此 ZIP 是固定 11 檔 runtime，不含 bootstrap、publisher、私鑰或原使用者資料；需配套安裝包與合法發布／activation 流程。
