Option Explicit
' Solar System Link POS 0.6.8 per-user bootstrap. ASCII source; UTF-16 owned manifest.
Const ProductVersion = "0.6.8"
Const AgentHash = "cf0aa2a48e5cf714e8c96a22e227e901858cd85c7acdb9a4b6c1f5308c965bc0"
Const ConfigHash = "600bb2b8a2eafa824a422c2431f289913297e9ed02aee321663919eb02ee85da"
Const ReadmeHash = "c4d603f6d5bf908467652813ccefd055fa292068bbf846bcc7198611a7bbe3db"
Const RegRoot = "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\SolarSystemLink.POS068r1\"
Dim fs, sh, testMode, testRoot, sourceRoot, appRoot, parentRoot, desktopLink, menuLink
Dim actionName, ownerName, lockPath, lockOwned, lockStream, lockReadStream, selfHash, failureCode, failureText, consoleMode, journalPath, cleanupWarning
Dim activeRegRoot, nativeRegistryFixture
Set fs = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
testMode = False : lockOwned = False : failureCode = 0 : failureText = "" : cleanupWarning = False
activeRegRoot = RegRoot : nativeRegistryFixture = False
consoleMode = (InStr(LCase(WScript.FullName), "cscript.exe") > 0)
On Error Resume Next
Call Main
If Err.Number <> 0 Then
 If failureCode = 0 Then failureCode = 6 : failureText = "Installation could not complete. Existing credentials and unknown files were not intentionally removed. Keep this installer and check the owned installation folder."
 Err.Clear
End If
' Keep the recognized marker file. Only the OS writer handle is the lock.
' Even a failed acquisition can own a reader that must be closed on this path.
If IsObject(lockStream) Then lockStream.Close
If IsObject(lockReadStream) Then lockReadStream.Close
If failureCode <> 0 Then
 If consoleMode Or testMode Then
  WScript.Echo "ERROR " & CStr(failureCode) & ": " & failureText
 Else
  MsgBox failureText, vbExclamation, "Solar System Link POS 0.6.8"
 End If
End If
WScript.Quit failureCode

Sub Progress(stage)
 If consoleMode Then WScript.Echo "SSL_PROGRESS|" & stage
End Sub
Sub Fail(code, message)
 failureCode = code : failureText = message
 Err.Raise vbObjectError + code, "SolarSystemLink.POS068r1", message
End Sub
Function JoinPath(parent, leaf)
 JoinPath = fs.BuildPath(parent, leaf)
End Function
Function Same(a, b)
 Same = (StrComp(CStr(a), CStr(b), vbTextCompare) = 0)
End Function
Function Quote(value)
 If InStr(value, Chr(34)) > 0 Or InStr(value, vbCr) > 0 Or InStr(value, vbLf) > 0 Or InStr(value, Chr(0)) > 0 Then Call Fail(2, "Invalid path.")
 Quote = Chr(34) & value & Chr(34)
End Function
Sub Ordinary(path)
 Dim current, attrs, parent
 current = fs.GetAbsolutePathName(path)
 Do While Len(current) > 0
  If fs.FileExists(current) Then
   attrs = fs.GetFile(current).Attributes
  ElseIf fs.FolderExists(current) Then
   attrs = fs.GetFolder(current).Attributes
  Else
   attrs = 0
  End If
  If (attrs And 1024) <> 0 Then Call Fail(4, "Links or junctions are not allowed in installer paths.")
  parent = fs.GetParentFolderName(current)
  If Same(parent, current) Then Exit Do
  current = parent
 Loop
End Sub
Sub EnsureFolder(path)
 Call Ordinary(path)
 If Not fs.FolderExists(path) Then fs.CreateFolder path
End Sub
Function KnownLockMarker(text)
 Dim currentMarker, legacyMarker
 currentMarker = "SOLAR-POS-INSTALL-LOCK-V2" & vbCrLf & "Root=" & appRoot & vbCrLf & "Owner=" & ownerName
 legacyMarker = "SOLAR-POS-INSTALL-LOCK" & vbCrLf & appRoot
 KnownLockMarker = (text = currentMarker Or text = legacyMarker)
End Function
Sub AcquireInstallerLock
 Dim created, createError, readError, appendError, marker, probe, probeError, text
 Call Ordinary(lockPath)
 If fs.FolderExists(lockPath) Then Call Fail(4, "Unknown lock directory was preserved. Do not delete it; request installer support.")
 If Not fs.FileExists(lockPath) Then
  ' Finish the marker before taking the reusable append handle. A concurrent
  ' creator may win; that file must still pass the same strict checks below.
  marker = "SOLAR-POS-INSTALL-LOCK-V2" & vbCrLf & "Root=" & appRoot & vbCrLf & "Owner=" & ownerName
  On Error Resume Next
  Set created = fs.CreateTextFile(lockPath, False, True)
  createError = Err.Number : Err.Clear
  If createError = 0 Then
   created.Write marker
   createError = Err.Number : Err.Clear
   created.Close
   If createError = 0 Then createError = Err.Number
   Err.Clear
  End If
  On Error GoTo 0
  If createError <> 0 And Not fs.FileExists(lockPath) Then Call Fail(5, "Cannot create the local installer lock. No permissions or existing locks were changed.")
 End If
 If fs.GetFile(lockPath).Size > 2048 Then Call Fail(4, "Unknown or damaged lock was preserved. Do not delete it; request installer support.")
 On Error Resume Next
 Set lockReadStream = fs.OpenTextFile(lockPath, 1, False, -1)
 readError = Err.Number : Err.Clear
 If readError = 0 Then
  text = ""
  If Not lockReadStream.AtEndOfStream Then text = lockReadStream.ReadAll
  readError = Err.Number : Err.Clear
 End If
 On Error GoTo 0
 If readError <> 0 Then Call Fail(5, "The installer lock cannot be read safely. No lock was removed or permission changed.")
 If Not KnownLockMarker(text) Then Call Fail(4, "Unknown or incomplete installer lock was preserved. Another installer may still be starting; retry after it exits, or request support. Do not delete the lock.")
 ' The reader remains open across acquisition, preventing path replacement.
 ' ASCII append mode never truncates or rewrites the UTF-16 marker; no Write
 ' is ever issued to this handle. A live holder's writer share denies entry.
 On Error Resume Next
 Set lockStream = fs.OpenTextFile(lockPath, 8, False, 0)
 appendError = Err.Number : Err.Clear
 On Error GoTo 0
 If appendError <> 0 Then Call Fail(5, "Cannot take an OS-exclusive installer writer handle. Another installer or file access may be blocking it; close your installer and retry. The lock was preserved.")
 ' Verify this host's FSO really enforces exclusive writer sharing. Never
 ' infer exclusivity from a PID or from the file merely being present.
 On Error Resume Next
 Set probe = fs.OpenTextFile(lockPath, 8, False, 0)
 probeError = Err.Number : Err.Clear
 If probeError = 0 Then probe.Close
 On Error GoTo 0
 If probeError <> 70 Then Call Fail(5, "OS-exclusive writer sharing could not be confirmed. Installation was not started and the lock was preserved.")
 If Not KnownLockMarker(ReadUnicode(lockPath)) Then Call Fail(4, "Installer lock changed during acquisition. It was preserved; request support.")
 lockOwned = True
End Sub
Function ReadUnicode(path)
 Dim input
 If Not fs.FileExists(path) Then Call Fail(4, "Required owned state is missing.")
 If fs.GetFile(path).Size > 16384 Then Call Fail(4, "Owned state is too large.")
 Call Ordinary(path)
 Set input = fs.OpenTextFile(path, 1, False, -1)
 ReadUnicode = input.ReadAll
 input.Close
End Function
Sub WriteUnicodeNew(path, value)
 Dim output
 Call Ordinary(path)
 Set output = fs.CreateTextFile(path, False, True)
 output.Write value
 output.Close
End Sub
Function IsHash(value)
 Dim regex
 Set regex = New RegExp
 regex.Pattern = "^[0-9a-f]{64}$"
 IsHash = regex.Test(value)
End Function
Function HashFile(path)
 Dim process, timerStart, line, compact, found, regex, output
 Call Ordinary(path)
 If Not fs.FileExists(path) Then Call Fail(3, "A required file is missing.")
 If fs.GetFile(path).Size > 5242880 Then Call Fail(3, "Unexpected payload size.")
 Set process = sh.Exec(Quote(sh.ExpandEnvironmentStrings("%SystemRoot%\System32\certutil.exe")) & " -hashfile " & Quote(path) & " SHA256")
 timerStart = Timer
 Do While process.Status = 0
  WScript.Sleep 20
  If Timer < timerStart Then timerStart = Timer
  If Timer - timerStart > 15 Then
   ' No force termination: this owned read-only probe remains unconfirmed.
   Call Fail(3, "File verification timed out; no application was started.")
  End If
 Loop
 output = process.StdOut.ReadAll
 If process.ExitCode <> 0 Then Call Fail(3, "SHA256 verification failed.")
 found = ""
 Set regex = New RegExp
 regex.Pattern = "^[0-9a-fA-F " & vbTab & "]+$"
 For Each line In Split(Replace(output, vbCr, ""), vbLf)
  line = Trim(line)
  If Len(line) > 0 Then
   If regex.Test(line) Then
    compact = LCase(Replace(Replace(line, " ", ""), vbTab, ""))
    If IsHash(compact) Then
     If Len(found) <> 0 Then Call Fail(3, "Ambiguous SHA256 response.")
     found = compact
    End If
   End If
  End If
 Next
 If Not IsHash(found) Then Call Fail(3, "No valid SHA256 response.")
 HashFile = found
End Function
Function FixedNames()
 FixedNames = Array("SolarSystemLink.Agent.exe", "SolarSystemLink.Agent.exe.config", "README-POS.txt", "PosInstaller.vbs")
End Function
Function Expected(index)
 Select Case index
 Case 0 : Expected = AgentHash
 Case 1 : Expected = ConfigHash
 Case 2 : Expected = ReadmeHash
 Case 3 : Expected = selfHash
 End Select
End Function
Function SourceFile(index)
 Dim names
 names = FixedNames()
 If index = 3 Then
  SourceFile = WScript.ScriptFullName
 Else
  SourceFile = JoinPath(sourceRoot, names(index))
 End If
End Function
Sub CheckPrerequisites
 Dim arch, version, servicePack, release, mock, pieces, numbers, major, minor, regex
 If testMode Then
  mock = ReadUnicode(JoinPath(testRoot, "test-prerequisites.txt"))
  pieces = Split(mock, "|")
  If UBound(pieces) <> 3 Then Call Fail(2, "Invalid test prerequisites.")
  version = pieces(0) : servicePack = CLng(pieces(1)) : arch = pieces(2) : release = CLng(pieces(3))
 Else
  arch = sh.ExpandEnvironmentStrings("%PROCESSOR_ARCHITECTURE%")
  If Not Same(arch, "AMD64") Then arch = sh.ExpandEnvironmentStrings("%PROCESSOR_ARCHITEW6432%")
  version = sh.RegRead("HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\CurrentVersion")
  servicePack = 0
  If version = "6.1" Then servicePack = sh.RegRead("HKLM\SYSTEM\CurrentControlSet\Control\Windows\CSDVersion")
  On Error Resume Next
  release = sh.RegRead("HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\Release")
  If Err.Number <> 0 Then release = 0 : Err.Clear
  On Error GoTo 0
 End If
 Set regex = New RegExp
 regex.Pattern = "^[0-9]{1,2}\.[0-9]{1,2}$"
 If Not regex.Test(version) Then Call Fail(2, "Unknown Windows version format.")
 numbers = Split(version, ".") : major = CLng(numbers(0)) : minor = CLng(numbers(1))
 If Not Same(arch, "AMD64") Or major < 6 Or (major = 6 And minor < 1) Then Call Fail(2, "Windows 7 SP1 x64 or later is required. Nothing was downloaded or changed.")
 If major = 6 And minor = 1 And servicePack < 256 Then Call Fail(2, "Windows 7 Service Pack 1 is required.")
 If release < 528040 Then Call Fail(2, ".NET Framework 4.8 is required. Install it through your approved process, then run this installer again. This installer does not download or install prerequisites.")
End Sub
Sub ParseAndPaths
 Dim args, workspace, allowed, localRoot, startMenu, fixtureId, regex
 Set args = WScript.Arguments
 actionName = "install" : sourceRoot = fs.GetParentFolderName(WScript.ScriptFullName)
 If args.Count = 1 Then
  If LCase(args(0)) <> "/uninstall" Then Call Fail(2, "Invalid installer argument.")
  actionName = "uninstall"
 ElseIf args.Count > 0 Then
  If args.Count <> 7 Then Call Fail(2, "Invalid test arguments.")
  If LCase(args(0)) <> "/test-root" Or LCase(args(2)) <> "/source" Or LCase(args(4)) <> "/action" Or LCase(args(6)) <> "/no-launch" Then Call Fail(2, "Invalid test arguments.")
  testRoot = fs.GetAbsolutePathName(args(1))
  sourceRoot = fs.GetAbsolutePathName(args(3))
  actionName = LCase(args(5))
  If actionName <> "install" And actionName <> "uninstall" Then Call Fail(2, "Invalid test action.")
  workspace = fs.GetParentFolderName(fs.GetParentFolderName(fs.GetParentFolderName(WScript.ScriptFullName)))
  allowed = JoinPath(workspace, "artifacts")
  If Not Same(fs.GetParentFolderName(testRoot), allowed) Or LCase(Left(fs.GetFileName(testRoot), 20)) <> "pos-installer-tests-" Then Call Fail(2, "Test scope must be a new owned workspace artifact.")
  Call Ordinary(testRoot)
  If Not Same(fs.GetParentFolderName(sourceRoot), testRoot) Then Call Fail(2, "Test payload is outside its fixture.")
  If ReadUnicode(JoinPath(testRoot, ".solar-pos-installer-test")) <> "SOLAR-POS-INSTALLER-TEST-V1" & vbCrLf & testRoot Then Call Fail(2, "Test ownership marker mismatch.")
  testMode = True
  If fs.FileExists(JoinPath(testRoot, "native-registry-id.txt")) Then
   fixtureId = ReadUnicode(JoinPath(testRoot, "native-registry-id.txt"))
   Set regex = New RegExp : regex.Pattern = "^[0-9a-f]{32}$"
   If Not regex.Test(fixtureId) Then Call Fail(2, "Invalid owned registry fixture identity.")
   nativeRegistryFixture = True
   activeRegRoot = "HKCU\Software\SolarSystemLink\InstallerTests\" & fixtureId & "\"
  End If
 End If
 If testMode Then
  ownerName = "owned-test-user"
  localRoot = JoinPath(testRoot, "LocalAppData")
  desktopLink = JoinPath(JoinPath(testRoot, "Desktop"), "Solar System Link POS 0.6.8.lnk")
  menuLink = JoinPath(JoinPath(testRoot, "StartMenu"), "Solar System Link POS 0.6.8.lnk")
 Else
  ownerName = sh.ExpandEnvironmentStrings("%USERDOMAIN%\%USERNAME%")
  localRoot = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")
  desktopLink = JoinPath(sh.SpecialFolders("Desktop"), "Solar System Link POS 0.6.8.lnk")
  startMenu = JoinPath(sh.SpecialFolders("Programs"), "Solar System Link POS 0.6.8.lnk")
  menuLink = startMenu
 End If
 Call Quote(localRoot)
 Call Ordinary(localRoot)
 parentRoot = JoinPath(localRoot, "SolarSystemLink")
 appRoot = JoinPath(parentRoot, "POS-0.6.8-r1")
 lockPath = JoinPath(parentRoot, ".pos-install-068-r1.lock")
 journalPath = JoinPath(parentRoot, ".pos-transaction-068-r1.txt")
 Call Ordinary(sourceRoot) : Call Ordinary(appRoot) : Call Ordinary(desktopLink) : Call Ordinary(menuLink)
End Sub
Function UninstallCommand()
 UninstallCommand = Quote(sh.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe")) & " //nologo " & Quote(JoinPath(appRoot, "PosInstaller.vbs")) & " /uninstall"
End Function
Function RegistryPresent()
 Dim registry, value, registryError, name, readError
 If testMode And Not nativeRegistryFixture Then
  RegistryPresent = fs.FileExists(JoinPath(testRoot, "mock-registry.txt"))
 Else
  ' In-process HKCU, unlike the service-hosted StdRegProv HKCU context.
  On Error Resume Next
  Set registry = CreateObject("WindowsInstaller.Installer")
  value = registry.RegistryValue(1, Mid(activeRegRoot, 6, Len(activeRegRoot) - 6))
  registryError = Err.Number
  Err.Clear : On Error GoTo 0
  If registryError <> 0 Or VarType(value) <> 11 Then Call Fail(4, "Unable to verify this user's uninstall state; no registry absence was assumed.")
  If Not value Then
   ' Require the writer/reader API to agree with the presence API.
   For Each name In RegistryFields()
    On Error Resume Next
    value = sh.RegRead(activeRegRoot & name)
    readError = Err.Number : Err.Clear : On Error GoTo 0
    If readError <> &H80070002 And readError <> &H80070003 Then Call Fail(4, "Registry views disagree or access is unavailable; existing state was preserved.")
   Next
   RegistryPresent = False
  Else
   RegistryPresent = True
  End If
 End If
End Function
Function RegistryFields()
 RegistryFields = Array("DisplayName", "DisplayVersion", "Publisher", "InstallLocation", "UninstallString", "DisplayIcon", "NoModify", "NoRepair")
End Function
Function RegistryTypes()
 Dim registry, names, parsed, key, name, i, subkey, process, began, output, line, regex, matches, headerCount
 Set names = CreateObject("Scripting.Dictionary")
 Set registry = CreateObject("WindowsInstaller.Installer")
 key = Mid(activeRegRoot, 6, Len(activeRegRoot) - 6)
 For i = 1 To 9
  name = registry.RegistryValue(1, key, i)
  If IsEmpty(name) Then Exit For
  If VarType(name) <> 8 Then Call Fail(4, "Unable to enumerate owned registry values safely.")
  If Len(name) = 0 Then Exit For
  If i > 8 Then Call Fail(4, "Unknown uninstall values were preserved.")
  Select Case name
  Case "DisplayName", "DisplayVersion", "Publisher", "InstallLocation", "UninstallString", "DisplayIcon", "NoModify", "NoRepair"
  Case Else : Call Fail(4, "Unknown uninstall values were preserved.")
  End Select
  If names.Exists(name) Then Call Fail(4, "Ambiguous uninstall values were preserved.")
  names.Add name, True
 Next
 subkey = registry.RegistryValue(1, key, -1)
 If IsEmpty(subkey) Then subkey = ""
 If VarType(subkey) <> 8 Then Call Fail(4, "Unable to enumerate owned registry subkeys safely.")
 If Len(subkey) <> 0 Then Call Fail(4, "Unknown uninstall subkeys were preserved.")
 Set process = sh.Exec(Quote(sh.ExpandEnvironmentStrings("%SystemRoot%\System32\reg.exe")) & " query " & Quote(Left(activeRegRoot, Len(activeRegRoot) - 1)))
 began = Timer
 Do While process.Status = 0
  WScript.Sleep 20
  If Timer < began Then began = Timer
  If Timer - began > 10 Then
   ' No force termination: this owned read-only probe remains unconfirmed.
   Call Fail(4, "Owned registry verification timed out; no registry data was changed.")
  End If
 Loop
 If process.ExitCode <> 0 Then Call Fail(4, "Unable to verify owned registry types; no missing key was assumed.")
 output = process.StdOut.Read(8193)
 If Len(output) > 8192 Or Not process.StdOut.AtEndOfStream Then Call Fail(4, "Owned registry output exceeded its safe bound.")
 Set parsed = CreateObject("Scripting.Dictionary")
 Set regex = New RegExp : regex.Pattern = "^[ \t]+([A-Za-z]+)[ \t]+(REG_SZ|REG_DWORD)[ \t]+.*$"
 headerCount = 0
 For Each line In Split(Replace(output, vbCr, ""), vbLf)
  If Len(Trim(line)) <> 0 Then
   If Trim(line) = "HKEY_CURRENT_USER\" & key Then
    headerCount = headerCount + 1
   Else
    If Not regex.Test(line) Then Call Fail(4, "Unknown registry output, names or types were preserved.")
    Set matches = regex.Execute(line) : name = matches(0).SubMatches(0)
    If Not names.Exists(name) Then Call Fail(4, "Registry enumeration views disagree; state was preserved.")
    If parsed.Exists(name) Then Call Fail(4, "Duplicate registry output was preserved.")
    parsed.Add name, matches(0).SubMatches(1)
   End If
  End If
 Next
 If headerCount <> 1 Or parsed.Count <> names.Count Then Call Fail(4, "Incomplete registry enumeration was preserved.")
 Set RegistryTypes = parsed
End Function
Sub CheckOwnedRegistry
 Dim value, types
 If testMode And Not nativeRegistryFixture Then
  If ReadUnicode(JoinPath(testRoot, "mock-registry.txt")) <> appRoot & vbCrLf & UninstallCommand() Then Call Fail(4, "An unknown uninstall entry was preserved.")
 Else
  Call CheckPendingRegistry
  Set types = RegistryTypes()
  If types.Count <> 8 Then Call Fail(4, "Incomplete uninstall ownership was preserved.")
 End If
End Sub
Sub WriteRegistry
 If testMode And Not nativeRegistryFixture Then
  Call WriteUnicodeNew(JoinPath(testRoot, "mock-registry.txt"), appRoot & vbCrLf & UninstallCommand())
 Else
  sh.RegWrite activeRegRoot & "DisplayName", "Solar System Link POS 0.6.8", "REG_SZ"
  sh.RegWrite activeRegRoot & "DisplayVersion", ProductVersion, "REG_SZ"
  sh.RegWrite activeRegRoot & "Publisher", "Solar System Link", "REG_SZ"
  sh.RegWrite activeRegRoot & "InstallLocation", appRoot, "REG_SZ"
  sh.RegWrite activeRegRoot & "UninstallString", UninstallCommand(), "REG_SZ"
  sh.RegWrite activeRegRoot & "DisplayIcon", JoinPath(appRoot, "SolarSystemLink.Agent.exe"), "REG_SZ"
  sh.RegWrite activeRegRoot & "NoModify", 1, "REG_DWORD"
  sh.RegWrite activeRegRoot & "NoRepair", 1, "REG_DWORD"
  Call CheckOwnedRegistry
 End If
End Sub
Sub RemoveRegistry
 Call CheckOwnedRegistry
 If testMode And Not nativeRegistryFixture Then
  fs.DeleteFile JoinPath(testRoot, "mock-registry.txt"), False
 Else
  sh.RegDelete activeRegRoot
 End If
End Sub
Sub CheckNotRunning
 Dim service, processes, process, exePath
 If testMode Then
  If fs.FileExists(JoinPath(testRoot, "active-agent.flag")) Then Call Fail(5, "POS Agent is running. Close its normal window before installing or removing it. No process was terminated.")
 Else
  Set service = GetObject("winmgmts:\\.\root\cimv2")
  Set processes = service.ExecQuery("SELECT ExecutablePath FROM Win32_Process WHERE Name='SolarSystemLink.Agent.exe' OR Name='SSS.RemoteManagement.exe'")
  For Each process In processes
   exePath = process.ExecutablePath
   If IsNull(exePath) Then Call Fail(5, "An Agent process could not be identified. Close the Agent before continuing.")
   Call Fail(5, "POS Agent is running. Close its normal window first. No process was terminated.")
  Next
 End If
End Sub
Sub CreateLink(path)
 Dim link
 If fs.FileExists(path) Or fs.FolderExists(path) Then Call Fail(4, "An existing shortcut was preserved; choose a clean per-user installation.")
 Set link = sh.CreateShortcut(path)
 link.TargetPath = JoinPath(appRoot, "SolarSystemLink.Agent.exe")
 link.WorkingDirectory = appRoot
 link.IconLocation = JoinPath(appRoot, "SolarSystemLink.Agent.exe") & ",0"
 link.Description = "Solar System Link POS 0.6.8 (manual sharing only)"
 link.Save
End Sub
Function LinkOwned(path, expectedHash)
 Dim link
 LinkOwned = False
 If Not fs.FileExists(path) Then Exit Function
 If HashFile(path) <> expectedHash Then Exit Function
 Set link = sh.CreateShortcut(path)
 If Not Same(link.TargetPath, JoinPath(appRoot, "SolarSystemLink.Agent.exe")) Then Exit Function
 If Len(link.Arguments) <> 0 Then Exit Function
 If Not Same(link.WorkingDirectory, appRoot) Then Exit Function
 If Not Same(link.IconLocation, JoinPath(appRoot, "SolarSystemLink.Agent.exe") & ",0") Then Exit Function
 LinkOwned = True
End Function
Function ParseManifest(text, checkFiles)
 Dim lines, names, records, i, pieces
 lines = Split(text, vbCrLf)
 If UBound(lines) <> 10 Then Call Fail(4, "Unknown or damaged installation manifest. No files were removed.")
 If lines(0) <> "SOLAR-POS-INSTALL-V1" Or Not Same(lines(1), "Root=" & appRoot) Or lines(2) <> "Owner=" & ownerName Or lines(3) <> "Version=" & ProductVersion Or lines(10) <> "Registry=SolarSystemLink.POS068r1" Then Call Fail(4, "Unknown installation ownership. No files were removed.")
 names = FixedNames()
 Set records = CreateObject("Scripting.Dictionary")
 For i = 0 To 3
  pieces = Split(lines(4 + i), "|")
  If UBound(pieces) <> 1 Then Call Fail(4, "Invalid owned file list.")
  If pieces(0) <> "File=" & names(i) Or Not IsHash(pieces(1)) Then Call Fail(4, "Invalid owned file whitelist.")
  If pieces(1) <> Expected(i) Then Call Fail(4, "A different POS installer or version was preserved. Use its original uninstaller first.")
  If checkFiles Then
   If HashFile(JoinPath(appRoot, names(i))) <> pieces(1) Then Call Fail(4, "An installed file was changed. It was preserved.")
  End If
  records.Add names(i), pieces(1)
 Next
 For i = 0 To 1
  pieces = Split(lines(8 + i), "|")
  If UBound(pieces) <> 1 Then Call Fail(4, "Invalid owned shortcut list.")
  If pieces(0) <> "Shortcut=" & CStr(i) Or Not IsHash(pieces(1)) Then Call Fail(4, "Invalid owned shortcut whitelist.")
  records.Add "shortcut" & CStr(i), pieces(1)
 Next
 records.Add "manifestText", text
 Set ParseManifest = records
End Function
Function LoadManifest()
 Dim records
 Set records = ParseManifest(ReadUnicode(JoinPath(appRoot, "install-manifest.txt")), True)
 Call CheckOwnedRegistry
 Set LoadManifest = records
End Function
Function ManifestFor(records)
 Dim text, names, i
 names = FixedNames()
 text = "SOLAR-POS-INSTALL-V1" & vbCrLf & "Root=" & appRoot & vbCrLf & "Owner=" & ownerName & vbCrLf & "Version=" & ProductVersion
 For i = 0 To 3
  text = text & vbCrLf & "File=" & names(i) & "|" & records(names(i))
 Next
 ManifestFor = text & vbCrLf & "Shortcut=0|" & records("shortcut0") & vbCrLf & "Shortcut=1|" & records("shortcut1") & vbCrLf & "Registry=SolarSystemLink.POS068r1"
End Function
Sub WriteJournal(kind, stage, manifest)
 ' The complete hash whitelist is durable before installed paths are changed.
 Call WriteUnicodeNew(journalPath, "SOLAR-POS-PENDING-V2" & vbCrLf & "Action=" & kind & vbCrLf & "Stage=" & stage & vbCrLf & manifest)
End Sub
Function LoadJournal()
 Dim lines, text, i, records, stage, kind, journalText
 journalText = ReadUnicode(journalPath)
 lines = Split(journalText, vbCrLf)
 If UBound(lines) <> 13 Or lines(0) <> "SOLAR-POS-PENDING-V2" Then Call Fail(4, "Damaged pending journal was preserved; use manual support, not automatic recovery.")
 kind = lines(1)
 If kind <> "Action=install" And kind <> "Action=uninstall" Then Call Fail(4, "Unknown pending transaction was preserved.")
 If Left(lines(2), 6) <> "Stage=" Then Call Fail(4, "Invalid pending staging path.")
 stage = Mid(lines(2), 7)
 If Len(stage) > 0 Then
  If Not Same(fs.GetParentFolderName(stage), parentRoot) Or Left(fs.GetFileName(stage), 11) <> ".pos-stage-" Or Not Same(fs.GetAbsolutePathName(stage), stage) Then Call Fail(4, "Pending staging path is outside its owned parent.")
  Call Ordinary(stage)
 ElseIf kind = "Action=install" Then
  Call Fail(4, "Pending installation has no verified staging directory.")
 End If
 text = lines(3)
 For i = 4 To 13
  text = text & vbCrLf & lines(i)
 Next
 Set records = ParseManifest(text, False)
 records.Add "stage", stage : records.Add "action", kind : records.Add "journalText", journalText
 Set LoadJournal = records
End Function
Sub ValidatePresentFiles(records)
 Dim names, i, path
 names = FixedNames()
 For i = 0 To 3
  path = JoinPath(appRoot, names(i)) : Call Ordinary(path)
  If fs.FolderExists(path) Then Call Fail(4, "A file path is occupied by an unknown directory.")
  If fs.FileExists(path) Then
   If HashFile(path) <> records(names(i)) Then Call Fail(4, "A pending file was changed and was preserved.")
  End If
 Next
 path = JoinPath(appRoot, "install-manifest.txt")
 If fs.FolderExists(path) Then Call Fail(4, "An unknown manifest directory was preserved.")
 If fs.FileExists(path) Then
  If ReadUnicode(path) <> records("manifestText") Then Call Fail(4, "A pending installation manifest was changed and was preserved.")
 End If
End Sub
Sub CheckRemovalAttributes(records)
 Dim names, i, path
 names = FixedNames()
 For i = 0 To 3
  path = JoinPath(appRoot, names(i))
  If fs.FileExists(path) Then
   If (fs.GetFile(path).Attributes And 1) <> 0 Then Call Fail(4, "A read-only owned file prevents removal. No payload was removed; clear it only through your approved process and retry.")
  End If
 Next
 path = JoinPath(appRoot, "install-manifest.txt")
 If fs.FileExists(path) Then
  If (fs.GetFile(path).Attributes And 1) <> 0 Then Call Fail(4, "The owned manifest is read-only. No payload was removed.")
 End If
 If LinkOwned(desktopLink, records("shortcut0")) Then
  If (fs.GetFile(desktopLink).Attributes And 1) <> 0 Then Call Fail(4, "The owned desktop shortcut is read-only. No payload was removed.")
 End If
 If LinkOwned(menuLink, records("shortcut1")) Then
  If (fs.GetFile(menuLink).Attributes And 1) <> 0 Then Call Fail(4, "The owned menu shortcut is read-only. No payload was removed.")
 End If
End Sub
Sub PublishFile(source, destination, expectedHash)
 Dim temporary
 Call Ordinary(source) : Call Ordinary(destination)
 If fs.FolderExists(destination) Then Call Fail(4, "An unknown destination directory was preserved.")
 If fs.FileExists(destination) Then
  If HashFile(destination) <> expectedHash Then Call Fail(4, "An existing destination was changed and was preserved.")
  Exit Sub
 End If
 temporary = JoinPath(fs.GetParentFolderName(destination), ".pos-copy-" & fs.GetTempName())
 Call Ordinary(temporary)
 fs.CopyFile source, temporary, False
 If HashFile(temporary) <> expectedHash Then Call Fail(3, "Pending copied bytes failed verification and were not published.")
 fs.MoveFile temporary, destination
End Sub
Sub PublishManifest(text)
 Dim path, temporary
 path = JoinPath(appRoot, "install-manifest.txt")
 If fs.FileExists(path) Then
  If ReadUnicode(path) <> text Then Call Fail(4, "An existing manifest was preserved.")
  Exit Sub
 End If
 temporary = JoinPath(appRoot, ".pos-manifest-" & fs.GetTempName())
 Call WriteUnicodeNew(temporary, text)
 If ReadUnicode(temporary) <> text Then Call Fail(3, "Pending manifest verification failed.")
 fs.MoveFile temporary, path
End Sub
Sub CheckPendingRegistry
 Dim types, name, value, expectedType, actual, expectedVariant
 If testMode And Not nativeRegistryFixture Then
  If RegistryPresent() Then Call CheckOwnedRegistry
  Exit Sub
 End If
 If Not RegistryPresent() Then Exit Sub
 Set types = RegistryTypes()
 For Each name In types.Keys
  expectedType = "REG_SZ" : expectedVariant = 8
  Select Case name
  Case "DisplayName" : value = "Solar System Link POS 0.6.8"
  Case "DisplayVersion" : value = ProductVersion
  Case "Publisher" : value = "Solar System Link"
  Case "InstallLocation" : value = appRoot
  Case "UninstallString" : value = UninstallCommand()
  Case "DisplayIcon" : value = JoinPath(appRoot, "SolarSystemLink.Agent.exe")
  Case "NoModify", "NoRepair" : value = 1 : expectedType = "REG_DWORD" : expectedVariant = 3
  Case Else : Call Fail(4, "Unknown uninstall values were preserved.")
  End Select
  actual = sh.RegRead(activeRegRoot & name)
  If types(name) <> expectedType Or VarType(actual) <> expectedVariant Or CStr(actual) <> CStr(value) Then Call Fail(4, "Changed uninstall types or values were preserved.")
 Next
End Sub
Sub FixtureFault(point)
 If FixtureFlag(point) Then Call Fail(6, "Owned fixture I/O fault checkpoint; pending journal retained.")
End Sub
Function FixtureFlag(point)
 FixtureFlag = False
 If testMode Then FixtureFlag = fs.FileExists(JoinPath(testRoot, "fault-" & point & ".flag"))
End Function
Sub FixtureHoldLock
 Dim began
 If Not FixtureFlag("hold-lock") Then Exit Sub
 If Not lockOwned Then Call Fail(5, "Owned fixture never acquired its writer handle.")
 Call WriteUnicodeNew(JoinPath(testRoot, "lock-held.txt"), "OWNED-FIXTURE-LOCK-HELD")
 began = Timer
 Do While FixtureFlag("hold-lock")
  WScript.Sleep 20
  If Timer < began Then began = Timer
  If Timer - began > 20 Then Call Fail(6, "Owned lock-holder fixture deadline reached.")
 Loop
End Sub
Sub CleanStage(records)
 Dim names, i, stage, path
 stage = records("stage")
 If Len(stage) = 0 Then Exit Sub
 Call Ordinary(stage)
 names = FixedNames()
 For i = 0 To 3
  path = JoinPath(stage, names(i))
  If fs.FileExists(path) Then
   If HashFile(path) = records(names(i)) Then fs.DeleteFile path, False
  End If
 Next
 For i = 0 To 1
  path = JoinPath(stage, "shortcut" & CStr(i) & ".lnk")
  If fs.FileExists(path) Then
   If LinkOwned(path, records("shortcut" & CStr(i))) Then fs.DeleteFile path, False
  End If
 Next
 ' Empty staging directories and any unknown temporary/user files stay intact.
End Sub
Function StageCleanupWarning(records)
 Dim savedCode, savedText, cleanupError
 savedCode = failureCode : savedText = failureText
 On Error Resume Next
 Call CleanStage(records)
 cleanupError = Err.Number : Err.Clear
 On Error GoTo 0
 failureCode = savedCode : failureText = savedText
 StageCleanupWarning = ""
 If cleanupError <> 0 Then StageCleanupWarning = " Some staging files were preserved; the application commit is unaffected."
 If cleanupError <> 0 Then cleanupWarning = True
End Function
Function JournalCleanupWarning(records)
 Dim savedCode, savedText, cleanupError, warning
 savedCode = failureCode : savedText = failureText : warning = ""
 On Error Resume Next
 If fs.FileExists(journalPath) Then
  If ReadUnicode(journalPath) <> records("journalText") Then
   warning = " Changed pending state was preserved; manual support is required."
  ElseIf FixtureFlag("cleanup-journal") Then
   warning = " Application commit completed; the owned pending journal still needs cleanup. Run this setup again."
  Else
   fs.DeleteFile journalPath, False
  End If
 End If
 cleanupError = Err.Number : Err.Clear
 On Error GoTo 0
 failureCode = savedCode : failureText = savedText
 If cleanupError <> 0 Then warning = " Application commit completed; pending cleanup could not finish. Run this setup again or request manual support."
 If Len(warning) > 0 Then cleanupWarning = True
 JournalCleanupWarning = warning
End Function
Sub ResumeInstall(records)
 Dim names, i, stage, path, committed, warning
 stage = records("stage")
 If records("action") = "Action=uninstall" Then
  ' A normal setup launch can resume the previously authorized exact removal.
  ' Normal WScript still asks the existing uninstall confirmation below.
  actionName = "uninstall" : Call Uninstall : Exit Sub
 End If
 If fs.FileExists(JoinPath(appRoot, "install-manifest.txt")) Then
  Set committed = LoadManifest()
  If committed("manifestText") <> records("manifestText") Then Call Fail(4, "Committed state differs from the pending transaction.")
  If Not LinkOwned(desktopLink, records("shortcut0")) Or Not LinkOwned(menuLink, records("shortcut1")) Then Call Fail(4, "A committed shortcut was changed and was preserved.")
  warning = StageCleanupWarning(records) & JournalCleanupWarning(records)
  Call Success("The committed POS installation was verified." & warning)
  Exit Sub
 End If
 names = FixedNames()
 For i = 0 To 3
  If HashFile(JoinPath(stage, names(i))) <> records(names(i)) Then Call Fail(4, "Pending staging bytes were changed and were preserved.")
 Next
 For i = 0 To 1
  If Not LinkOwned(JoinPath(stage, "shortcut" & CStr(i) & ".lnk"), records("shortcut" & CStr(i))) Then Call Fail(4, "Pending staging shortcut was changed and was preserved.")
 Next
 Call ValidatePresentFiles(records) : Call CheckPendingRegistry
 Call EnsureFolder(appRoot)
 For i = 0 To 3
  Call PublishFile(JoinPath(stage, names(i)), JoinPath(appRoot, names(i)), records(names(i)))
 Next
 Call FixtureFault("after-payload")
 Call PublishFile(JoinPath(stage, "shortcut0.lnk"), desktopLink, records("shortcut0"))
 Call PublishFile(JoinPath(stage, "shortcut1.lnk"), menuLink, records("shortcut1"))
 If Not LinkOwned(desktopLink, records("shortcut0")) Or Not LinkOwned(menuLink, records("shortcut1")) Then Call Fail(4, "Published shortcut verification failed.")
 If testMode And Not nativeRegistryFixture Then
  If Not RegistryPresent() Then Call WriteRegistry
 Else
  Call WriteRegistry
 End If
 Call FixtureFault("after-registry")
 Call Progress("commit")
 Call PublishManifest(records("manifestText"))
 ' Commit is complete before optional staging cleanup; journal is removed last.
 warning = StageCleanupWarning(records) & JournalCleanupWarning(records)
 Call Success("POS installed for this Windows user. Sharing and control have not been started." & warning)
End Sub
Sub Install
 Dim names, i, manifest, records, folder, stage
 Call Progress("verify-payload")
 selfHash = HashFile(WScript.ScriptFullName)
 For i = 0 To 2
  If HashFile(SourceFile(i)) <> Expected(i) Then Call Fail(3, "The installer payload did not match its approved SHA256. Existing installation was not changed.")
 Next
 If fs.FileExists(journalPath) Then
  Set records = LoadJournal() : Call ResumeInstall(records) : Exit Sub
 End If
 If fs.FileExists(JoinPath(appRoot, "install-manifest.txt")) Then
  Set records = LoadManifest()
  If records("PosInstaller.vbs") <> selfHash Then Call Fail(4, "A different installer revision was preserved. Use its original uninstaller first.")
  If Not LinkOwned(desktopLink, records("shortcut0")) Or Not LinkOwned(menuLink, records("shortcut1")) Then Call Fail(4, "An unknown shortcut was preserved.")
  Call Success("The same POS version is already installed and verified.")
  Exit Sub
 End If
 If fs.FolderExists(appRoot) Then
  Set folder = fs.GetFolder(appRoot)
  If folder.Files.Count <> 0 Or folder.SubFolders.Count <> 0 Then Call Fail(4, "An unknown installation folder was preserved.")
 End If
 If fs.FileExists(desktopLink) Or fs.FolderExists(desktopLink) Or fs.FileExists(menuLink) Or fs.FolderExists(menuLink) Or RegistryPresent() Then Call Fail(4, "Existing shortcuts or uninstall state were preserved.")
 Call Progress("stage")
 stage = JoinPath(parentRoot, ".pos-stage-" & fs.GetTempName())
 Call Ordinary(stage) : fs.CreateFolder stage
 names = FixedNames()
 Set records = CreateObject("Scripting.Dictionary")
 For i = 0 To 3
  fs.CopyFile SourceFile(i), JoinPath(stage, names(i)), False
  If HashFile(JoinPath(stage, names(i))) <> Expected(i) Then Call Fail(3, "Staged file verification failed. Installed state was not changed.")
  records.Add names(i), Expected(i)
 Next
 For i = 0 To 1
  Call CreateLink(JoinPath(stage, "shortcut" & CStr(i) & ".lnk"))
  records.Add "shortcut" & CStr(i), HashFile(JoinPath(stage, "shortcut" & CStr(i) & ".lnk"))
 Next
 manifest = ManifestFor(records)
 Call WriteJournal("install", stage, manifest)
 Set records = LoadJournal() : Call ResumeInstall(records)
End Sub
Sub Uninstall
 Dim names, i, records, warning
 If Not testMode Then
  If MsgBox("Remove this user's POS application and owned shortcuts? Fixed code, device identity, safety budget and extra user files will be kept.", vbYesNo + vbQuestion + vbDefaultButton2, "Solar System Link POS 0.6.8") <> vbYes Then Call Fail(8, "Removal cancelled.")
 End If
 If fs.FileExists(journalPath) Then
  Set records = LoadJournal()
  If records("action") <> "Action=uninstall" Then Call Fail(4, "An installation is pending. Resume the original setup before requesting removal; no payload was removed.")
 Else
  Set records = LoadManifest()
  Call WriteJournal("uninstall", "", records("manifestText"))
  Set records = LoadJournal()
 End If
 Call ValidatePresentFiles(records) : Call CheckPendingRegistry : Call CheckRemovalAttributes(records)
 warning = StageCleanupWarning(records)
 names = FixedNames()
 ' Retain the script and uninstall entry while any payload deletion can fail.
 For i = 0 To 2
  If fs.FileExists(JoinPath(appRoot, names(i))) Then
   If HashFile(JoinPath(appRoot, names(i))) <> records(names(i)) Then Call Fail(4, "A file changed during removal and was preserved.")
   fs.DeleteFile JoinPath(appRoot, names(i)), False
  End If
 Next
 If LinkOwned(desktopLink, records("shortcut0")) Then
  fs.DeleteFile desktopLink, False
 Else
  warning = " Modified or missing shortcuts were preserved."
 End If
 If LinkOwned(menuLink, records("shortcut1")) Then
  fs.DeleteFile menuLink, False
 Else
  warning = " Modified or missing shortcuts were preserved."
 End If
 If fs.FileExists(JoinPath(appRoot, "install-manifest.txt")) Then
  If ReadUnicode(JoinPath(appRoot, "install-manifest.txt")) <> records("manifestText") Then Call Fail(4, "The manifest changed and was preserved.")
  fs.DeleteFile JoinPath(appRoot, "install-manifest.txt"), False
 End If
 If fs.FileExists(JoinPath(appRoot, names(3))) Then
  If HashFile(JoinPath(appRoot, names(3))) <> records(names(3)) Then Call Fail(4, "The uninstall script changed and was preserved.")
  fs.DeleteFile JoinPath(appRoot, names(3)), False
 End If
 If RegistryPresent() Then
  Call CheckPendingRegistry
  Call FixtureFault("registry-delete")
  If testMode And Not nativeRegistryFixture Then
   fs.DeleteFile JoinPath(testRoot, "mock-registry.txt"), False
  Else
   sh.RegDelete activeRegRoot
  End If
 End If
 If RegistryPresent() Then Call Fail(6, "Uninstall registration remains; the exact pending journal was kept. Run this setup again.")
 warning = warning & JournalCleanupWarning(records)
 Call Success("POS application removed. Fixed code, device identity, safety budget, directories and extra user files were kept. To install again, run the original setup again." & warning)
End Sub
Sub Success(message)
 If testMode Then
  If fs.FileExists(JoinPath(testRoot, "success-action.txt")) Then fs.DeleteFile JoinPath(testRoot, "success-action.txt"), False
  Call WriteUnicodeNew(JoinPath(testRoot, "success-action.txt"), actionName)
 End If
 If testMode Or consoleMode Then
  WScript.Echo "SUCCESS: " & message
 ElseIf actionName = "install" Then
  If cleanupWarning Then MsgBox message, vbExclamation, "Solar System Link POS 0.6.8"
  MsgBox message & vbCrLf & "Open the Solar System Link POS 0.6.8 desktop shortcut when ready. Sharing has not started.", vbInformation, "Solar System Link POS 0.6.8"
 Else
  MsgBox message, vbInformation, "Solar System Link POS 0.6.8"
 End If
End Sub
Sub Main
 Dim preflight
 If Not IsHash(AgentHash) Or Not IsHash(ConfigHash) Or Not IsHash(ReadmeHash) Then Call Fail(2, "The reviewed payload hashes have not been injected. This template cannot install.")
 Call Progress("preflight")
 Call ParseAndPaths
 If actionName = "install" Then Call CheckPrerequisites
 selfHash = HashFile(WScript.ScriptFullName)
 ' Reject a different revision before creating a persistent reusable marker,
 ' so trying this setup cannot block that revision's original uninstaller.
 If fs.FileExists(journalPath) Then
  Set preflight = LoadJournal()
 ElseIf fs.FileExists(JoinPath(appRoot, "install-manifest.txt")) Then
  Set preflight = ParseManifest(ReadUnicode(JoinPath(appRoot, "install-manifest.txt")), False)
 End If
 Call EnsureFolder(parentRoot)
 Call Ordinary(lockPath)
 Call Ordinary(journalPath)
 If fs.FolderExists(journalPath) Then Call Fail(4, "An unknown pending-state directory was preserved.")
 Call Progress("lock")
 Call AcquireInstallerLock
 Call FixtureHoldLock
 Call CheckNotRunning
 If actionName = "install" Then
  Call Install
 Else
  Call Uninstall
 End If
End Sub
