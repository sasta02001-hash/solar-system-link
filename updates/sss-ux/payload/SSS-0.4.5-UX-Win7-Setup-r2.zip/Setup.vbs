Option Explicit
Dim sh, fs, svc, systems, os, ok, release, here, result
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
here = fs.GetParentFolderName(WScript.ScriptFullName)
If WScript.Arguments.Count <> 0 Then WScript.Quit 2
On Error Resume Next
Set svc = GetObject("winmgmts:\\.\root\cimv2")
Set systems = svc.ExecQuery("SELECT Version, ServicePackMajorVersion, OSArchitecture FROM Win32_OperatingSystem")
ok = False
For Each os In systems
  If Left(CStr(os.Version), 4) = "6.1." And CLng(os.ServicePackMajorVersion) >= 1 And InStr(CStr(os.OSArchitecture), "64") > 0 Then ok = True
Next
If Err.Number <> 0 Then ok = False
Err.Clear
release = sh.RegRead("HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\Release")
If Err.Number <> 0 Then release = 0
Err.Clear
On Error GoTo 0
If Not ok Then
  MsgBox "Target required: Windows 7 SP1 x64. No application files were installed.", 48, "SSS UX setup candidate"
  WScript.Quit 3
End If
If Not IsNumeric(release) Then release = 0
If CDbl(release) < 528040 Then
  MsgBox "Install Microsoft .NET Framework 4.8 and finish any required restart, then retry this setup." & vbCrLf & "https://dotnet.microsoft.com/download/dotnet-framework/net48", 48, "SSS UX setup candidate"
  WScript.Quit 4
End If
If Not fs.FileExists(fs.BuildPath(here, "SSS.UxSetup.exe")) Then
  MsgBox "Incomplete package. Extract all ZIP members into one folder.", 48, "SSS UX setup candidate"
  WScript.Quit 5
End If
result = sh.Run(Chr(34) & fs.BuildPath(here, "SSS.UxSetup.exe") & Chr(34), 1, True)
WScript.Quit result
