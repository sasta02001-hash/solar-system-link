Option Explicit
Dim fs, shell, target, result
If WScript.Arguments.Count <> 0 Then WScript.Quit 2
Set fs = CreateObject("Scripting.FileSystemObject")
target = fs.BuildPath(fs.GetParentFolderName(WScript.ScriptFullName), "SSS.UiRepair.exe")
Set shell = CreateObject("WScript.Shell")
result = shell.Run(Chr(34) & target & Chr(34), 0, True)
WScript.Quit result