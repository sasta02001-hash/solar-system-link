Option Explicit
Dim sh, fs, svc, systems, os, release, x64, here, result
If WScript.Arguments.Count <> 0 Then WScript.Quit 2
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
here = fs.GetParentFolderName(WScript.ScriptFullName)
On Error Resume Next
Set svc = GetObject("winmgmts:\\.\root\cimv2")
Set systems = svc.ExecQuery("SELECT OSArchitecture FROM Win32_OperatingSystem")
x64 = False
For Each os In systems
  If InStr(CStr(os.OSArchitecture), "64") > 0 Then x64 = True
Next
If Err.Number <> 0 Then x64 = False
Err.Clear
release = sh.RegRead("HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\Release")
If Err.Number <> 0 Then release = 0
Err.Clear
On Error GoTo 0
If Not x64 Then
  MsgBox "This package requires 64-bit Windows. No installer was started.", 48, "SSS setup version selector"
  WScript.Quit 3
End If
If Not IsNumeric(release) Then release = 0
If CDbl(release) < 528040 Then
  MsgBox "Install Microsoft .NET Framework 4.8 and finish any required restart, then retry." & vbCrLf & "https://dotnet.microsoft.com/download/dotnet-framework/net48", 48, "SSS setup version selector"
  WScript.Quit 4
End If
If Not fs.FileExists(fs.BuildPath(here, "SSS.AutoSetup.exe")) Then
  MsgBox "Incomplete download. Extract all ZIP members into one folder.", 48, "SSS setup version selector"
  WScript.Quit 5
End If
result = sh.Run(Chr(34) & fs.BuildPath(here, "SSS.AutoSetup.exe") & Chr(34), 1, True)
WScript.Quit result
