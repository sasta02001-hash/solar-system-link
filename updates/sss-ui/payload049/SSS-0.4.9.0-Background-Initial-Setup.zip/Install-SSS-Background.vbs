Option Explicit
Dim base, fs, shell, result
Set fs = CreateObject("Scripting.FileSystemObject")
base = fs.GetParentFolderName(WScript.ScriptFullName)
Set shell = CreateObject("WScript.Shell")
result = shell.Run(Chr(34) & fs.BuildPath(base, "SSS.UiInitialSetup.exe") & Chr(34), 0, True)
WScript.Quit result
