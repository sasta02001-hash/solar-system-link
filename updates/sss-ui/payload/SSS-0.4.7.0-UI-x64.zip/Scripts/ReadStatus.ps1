﻿param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('FirewallProfiles', 'FirewallRules', 'DefenderStatus', 'Threats')]
    [string]$Query
)

# Stage A: fixed, read-only queries only. No profile, arbitrary commands, elevation,
# scan start, policy changes, deletion or execution-policy bypass are supported.
$ErrorActionPreference = 'Stop'
$WarningPreference = 'SilentlyContinue'
$VerbosePreference = 'SilentlyContinue'
$DebugPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$InformationPreference = 'SilentlyContinue'
$PSModuleAutoloadingPreference = 'None'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$script:partial = $false
$script:moduleRoot = [IO.Path]::Combine($PSHOME, 'Modules')
$script:reply = [ordered]@{
    SchemaVersion = 1; Query = $Query; State = 'Unknown'; ErrorCategory = 'None'
    CheckedUtc = [DateTime]::UtcNow.ToString('o'); IsPartial = $false; Data = $null
}

function Import-SystemModule([string]$Name) {
    if ($Name -notin @('Microsoft.PowerShell.Utility', 'NetSecurity', 'Defender')) { throw [InvalidOperationException]::new('UnsupportedModule') }
    $moduleFile = [IO.Path]::Combine($script:moduleRoot, $Name, ($Name + '.psd1'))
    if (-not [IO.File]::Exists($moduleFile)) { throw [IO.FileNotFoundException]::new('MissingModule') }
    Microsoft.PowerShell.Core\Import-Module -Name $moduleFile -ErrorAction Stop -WarningAction SilentlyContinue | Microsoft.PowerShell.Core\Out-Null
}
function Error-Category($Record) {
    if ($Record.Exception -is [UnauthorizedAccessException] -or $Record.CategoryInfo.Category -eq 'PermissionDenied' -or $Record.Exception.HResult -eq -2147024891) { return 'AccessDenied' }
    if ($Record.Exception -is [IO.FileNotFoundException] -or $Record.Exception -is [System.Management.Automation.CommandNotFoundException]) { return 'MissingModule' }
    return 'QueryFailed'
}
function Short-Text($Value, [int]$Maximum = 512) {
    if ($null -eq $Value) { return $null }
    $text = [string]$Value
    if ($text.Length -gt $Maximum) { $script:partial = $true; $text = $text.Substring(0, $Maximum) }
    # Control characters are never passed to the UI or activity log.
    return [regex]::Replace($text, '[\x00-\x1F\x7F]', ' ')
}
function Nullable-Bool($Value) {
    if ($null -eq $Value) { return $null }
    if ([string]$Value -eq 'True') { return $true }
    if ([string]$Value -eq 'False') { return $false }
    return $null
}
function Nullable-Number($Value) {
    if ($null -eq $Value) { return $null }
    $number = 0L
    if ([long]::TryParse([string]$Value, [ref]$number)) { return $number }
    $script:partial = $true
    return $null
}
function Utc-Time($Value) {
    if ($null -eq $Value) { return $null }
    try {
        $time = [DateTime]$Value
        if ($time.Year -lt 2000 -or $time.ToUniversalTime() -gt [DateTime]::UtcNow.AddDays(1)) { return $null }
        return $time.ToUniversalTime().ToString('o')
    } catch { return $null }
}
function Resource-List($Values) {
    $list = @()
    foreach ($value in @($Values)) {
        if ($null -eq $value) { continue }
        if ($list.Count -ge 8) { $script:partial = $true; break }
        $list += (Short-Text $value)
    }
    return ,$list
}
function Copy-Threat($Item, $Summary) {
    $name = $null; $active = $null; $executed = $null
    if ($null -ne $Summary) {
        $name = Short-Text $Summary.ThreatName
        $active = Nullable-Bool $Summary.IsActive
        $executed = Nullable-Bool $Summary.DidThreatExecute
    }
    return [ordered]@{
        ThreatID = (Short-Text $Item.ThreatID 32); DetectionID = (Short-Text $Item.DetectionID 80)
        ThreatName = $name; IsActive = $active; DidThreatExecute = $executed
        ActionSuccess = (Nullable-Bool $Item.ActionSuccess)
        ThreatStatusID = (Nullable-Number $Item.ThreatStatusID)
        CurrentThreatExecutionStatusID = (Nullable-Number $Item.CurrentThreatExecutionStatusID)
        ThreatStatusErrorCode = (Nullable-Number $Item.ThreatStatusErrorCode)
        CleaningActionID = (Nullable-Number $Item.CleaningActionID)
        AdditionalActionsBitMask = (Nullable-Number $Item.AdditionalActionsBitMask)
        InitialDetectionUtc = (Utc-Time $Item.InitialDetectionTime)
        LastStatusChangeUtc = (Utc-Time $Item.LastThreatStatusChangeTime)
        RemediationUtc = (Utc-Time $Item.RemediationTime)
        Resources = (Resource-List $Item.Resources)
    }
}

try {
    if (-not [Environment]::Is64BitProcess -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw [PlatformNotSupportedException]::new('UnsupportedEnvironment') }
    $expectedHome = [IO.Path]::Combine([Environment]::GetFolderPath('Windows'), 'System32', 'WindowsPowerShell', 'v1.0')
    if (-not [string]::Equals($PSHOME.TrimEnd('\'), $expectedHome.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw [PlatformNotSupportedException]::new('UnsupportedEnvironment') }
    $env:PSModulePath = $script:moduleRoot
    Import-SystemModule 'Microsoft.PowerShell.Utility'

    switch ($Query) {
        'FirewallProfiles' {
            Import-SystemModule 'NetSecurity'
            $rows = @()
            foreach ($profile in @(NetSecurity\Get-NetFirewallProfile -PolicyStore ActiveStore -ErrorAction Stop)) {
                if ([string]$profile.Name -notin @('Domain', 'Private', 'Public')) { $script:partial = $true; continue }
                $rows += [ordered]@{
                    Name = [string]$profile.Name; Enabled = (Nullable-Bool $profile.Enabled)
                    DefaultInboundAction = (Short-Text $profile.DefaultInboundAction 32)
                    DefaultOutboundAction = (Short-Text $profile.DefaultOutboundAction 32)
                    AllowLocalFirewallRules = (Nullable-Bool $profile.AllowLocalFirewallRules)
                }
            }
            if ($rows.Count -ne 3) { $script:partial = $true }
            $script:reply.Data = [ordered]@{ Profiles = @($rows) }
        }
        'FirewallRules' {
            Import-SystemModule 'NetSecurity'
            $rows = @(); $activeNames = @{}; $activeKnown = $true
            try {
                foreach ($rule in @(NetSecurity\Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop)) {
                    if ([string]$rule.Group -eq 'SolarSystemShield.Managed' -and ([string]$rule.Name).StartsWith('SolarSystemShield-Block-', [StringComparison]::Ordinal)) { $activeNames[[string]$rule.Name] = $true }
                }
            } catch { $activeKnown = $false; $script:partial = $true }
            foreach ($rule in @(NetSecurity\Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop)) {
                if ([string]$rule.Group -ne 'SolarSystemShield.Managed' -or -not ([string]$rule.Name).StartsWith('SolarSystemShield-Block-', [StringComparison]::Ordinal)) { continue }
                if ($rows.Count -ge 100) { $script:partial = $true; break }
                $program = $null
                try {
                    $filters = @($rule | NetSecurity\Get-NetFirewallApplicationFilter -ErrorAction Stop)
                    if ($filters.Count -eq 1) { $program = Short-Text $filters[0].Program } else { $script:partial = $true }
                } catch { $script:partial = $true }
                $present = $null
                if ($activeKnown) { $present = $activeNames.ContainsKey([string]$rule.Name) }
                $rows += [ordered]@{
                    Name = (Short-Text $rule.Name 120); DisplayName = (Short-Text $rule.DisplayName 256)
                    Program = $program; Enabled = (Nullable-Bool $rule.Enabled)
                    Direction = (Short-Text $rule.Direction 32); Action = (Short-Text $rule.Action 32)
                    Stored = $true; ActivePolicyPresent = $present; SourcePolicy = 'PersistentStore'
                    HasProtectedLedgerEvidence = $false; PacketTested = $false
                }
            }
            $script:reply.Data = [ordered]@{ Items = @($rows); IsComplete = (-not $script:partial) }
        }
        'DefenderStatus' {
            Import-SystemModule 'Defender'
            $status = Defender\Get-MpComputerStatus -ErrorAction Stop
            if ($null -eq $status) { throw [InvalidOperationException]::new('NoStatus') }
            $script:reply.Data = [ordered]@{
                Mode = (Short-Text $status.AMRunningMode 80)
                AntivirusEnabled = (Nullable-Bool $status.AntivirusEnabled)
                RealTimeProtectionEnabled = (Nullable-Bool $status.RealTimeProtectionEnabled)
                SignatureUpdatedUtc = (Utc-Time $status.AntivirusSignatureLastUpdated)
                QuickScanEndUtc = (Utc-Time $status.QuickScanEndTime); FullScanEndUtc = (Utc-Time $status.FullScanEndTime)
                PlatformVersion = (Short-Text $status.AMProductVersion 80); EngineVersion = (Short-Text $status.AMEngineVersion 80)
                SignatureVersion = (Short-Text $status.AntivirusSignatureVersion 80)
            }
        }
        'Threats' {
            Import-SystemModule 'Defender'
            $summaries = @{}; $active = @(); $history = @(); $currentState = 'Succeeded'; $historyState = 'Succeeded'
            $sourcePlatform = $null; $sourceEngine = $null
            try {
                $sourceStatus = Defender\Get-MpComputerStatus -ErrorAction Stop
                $sourcePlatform = Short-Text $sourceStatus.AMProductVersion 40
                $sourceEngine = Short-Text $sourceStatus.AMEngineVersion 40
                if ([string]::IsNullOrEmpty($sourcePlatform) -or [string]::IsNullOrEmpty($sourceEngine)) { $script:partial = $true }
            } catch { $script:partial = $true }
            try {
                foreach ($item in @(Defender\Get-MpThreat -ErrorAction Stop)) {
                    if ($summaries.Count -ge 200) { $script:partial = $true; break }
                    $id = [string]$item.ThreatID
                    if ([string]::IsNullOrEmpty($id) -or $summaries.ContainsKey($id)) { $script:partial = $true; continue }
                    $summaries[$id] = $item
                    if ((Nullable-Bool $item.IsActive) -eq $true) { $active += (Copy-Threat $item $item) }
                    elseif ($null -eq (Nullable-Bool $item.IsActive)) { $script:partial = $true }
                }
            } catch { $currentState = 'Failed'; $script:partial = $true }
            try {
                $keys = @{}
                foreach ($item in @(Defender\Get-MpThreatDetection -ErrorAction Stop)) {
                    if ($history.Count -ge 200) { $script:partial = $true; break }
                    $summary = $null
                    if ($summaries.ContainsKey([string]$item.ThreatID)) { $summary = $summaries[[string]$item.ThreatID] }
                    $record = Copy-Threat $item $summary
                    $key = [string]$record.ThreatID + '|' + [string]$record.DetectionID
                    if ([string]::IsNullOrEmpty($record.ThreatID) -or [string]::IsNullOrEmpty($record.DetectionID) -or $keys.ContainsKey($key)) { $script:partial = $true }
                    else { $keys[$key] = $true }
                    if ($null -eq $record.ThreatStatusID -or $record.ThreatStatusID -notin @(1,2,3,4,5,6,102,103,104,105,107) -or $null -eq $record.CurrentThreatExecutionStatusID -or $record.CurrentThreatExecutionStatusID -notin @(1,2,3,4)) { $script:partial = $true }
                    $history += $record
                }
            } catch { $historyState = 'Failed'; $script:partial = $true }
            $module = Microsoft.PowerShell.Core\Get-Module -Name Defender
            $script:reply.Data = [ordered]@{
                ActiveItems = @($active); HistoryItems = @($history); CurrentQueryState = $currentState
                HistoryQueryState = $historyState; IsComplete = (-not $script:partial)
                SourceVersion = ('Module:' + [string]$module.Version + ';Platform:' + $sourcePlatform + ';Engine:' + $sourceEngine)
            }
        }
    }
    $script:reply.IsPartial = $script:partial
    if ($script:partial) { $script:reply.State = 'Unknown'; $script:reply.ErrorCategory = 'InvalidData' }
    else { $script:reply.State = 'Succeeded' }
} catch {
    $script:reply.State = 'Failed'
    if ($_.Exception -is [PlatformNotSupportedException]) { $script:reply.ErrorCategory = 'UnsupportedEnvironment' }
    else { $script:reply.ErrorCategory = Error-Category $_ }
}
$script:reply.CheckedUtc = [DateTime]::UtcNow.ToString('o')
try {
    $json = Microsoft.PowerShell.Utility\ConvertTo-Json -InputObject $script:reply -Depth 8 -Compress
    if ($json.Length -gt 250000) {
        $script:reply.State = 'Unknown'; $script:reply.ErrorCategory = 'OutputLimit'; $script:reply.IsPartial = $true; $script:reply.Data = $null
        $json = Microsoft.PowerShell.Utility\ConvertTo-Json -InputObject $script:reply -Depth 3 -Compress
    }
    [Console]::Write($json)
} catch {
    [Console]::Write('{"SchemaVersion":1,"State":"Failed","ErrorCategory":"QueryFailed"}')
    exit 1
}
