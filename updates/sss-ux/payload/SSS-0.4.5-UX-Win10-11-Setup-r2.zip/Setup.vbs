Option Explicit
Dim sh, fs, here, target, result
If WScript.Arguments.Count <> 0 Then WScript.Quit 2
On Error Resume Next
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
here = fs.GetParentFolderName(WScript.ScriptFullName)
target = fs.BuildPath(here, "SSS.DesktopSetup.exe")
If Err.Number <> 0 Then WScript.Quit 3
If Not fs.FileExists(target) Or Not fs.FileExists(target & ".config") Then WScript.Quit 4
result = sh.Run(Chr(34) & target & Chr(34), 1, True)
If Err.Number <> 0 Then WScript.Quit 5
WScript.Quit result
